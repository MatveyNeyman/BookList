var app = angular.module('app', []);

app.controller('MainCtrl', function($scope) {

  $scope.fields = [
    {
      name: "quantity",
      label: "Item(s)/Qty",
      show: true,
      position: 0
    },
    {
      name: "surcharge",
      label: "Surcharge",
      show: true,
      position: 1
    },
    {
      name: "discount",
      label: "Discount",
      show: true,
      position: 2
    },
    {
      name: "subtotal",
      label: "Subtotal",
      show: true,
      position: 3
    },
    {
      name: "netTotal",
      label: "Net total",
      show: true,
      position: 4
    },
    {
      name: "tax",
      label: "Tax",
      show: true,
      position: 5
    },
    {
      name: "balance",
      label: "Balance Due",
      show: true,
      position: 6
    }
  ];

  $scope.moveUp = function(index) {
    if (index > 0) {
      for (var i = 0; i < $scope.fields.length; i++) {
        if ($scope.fields[i].position == index) {
          $scope.fields[i].position--;
          $scope.fields[i-1].position++;
        }
      }
      sortFieldsByPosition();
    }
  };

  $scope.moveDown = function(index) {
    if (index < $scope.fields.length-1) {
      for (var i = $scope.fields.length - 1; i >= 0; i--) {
        if ($scope.fields[i].position == index) {
          $scope.fields[i].position++;
          $scope.fields[i+1].position--;
        }
      }
      sortFieldsByPosition();
    }
  };

  function sortFieldsByPosition(){
    $scope.fields.sort(function(a, b){
      return a.position-b.position
    });
  }

});
