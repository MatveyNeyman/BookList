var app = angular.module('app', []);

app.controller('MainCtrl', ['$scope', function(scope) {
  scope.tableData = {};
  scope.tableData.series = [{
                    name: "Polo",
                    data: [365, 550, 620, 750, 890]
                },
                {
                    name: "Bike",
                    data: [180, 170, 220, 350, 450]
                },
                {
                    name: "Gloves",
                    data: [740, 620, 200, 150, 50]
                },
                {
                    name: "Tent",
                    data: [170, 230, 380, 420, 560]
                }];
  scope.tableData.categories = ["January", "February", "March", "April", "May"];

  scope.addRow = function () {
      var catLen = scope.tableData.categories.length;
      var cat = angular.copy(scope.tableData.categories[catLen - 1]);
      scope.tableData.categories.push(cat);
      for (var i = 0; i < scope.tableData.series.length; i++) {
          var serDataLen = scope.tableData.series[i].data.length;
          var serData = angular.copy(scope.tableData.series[i].data[serDataLen - 1]);
          scope.tableData.series[i].data.push(serData);
      }
  };

  scope.deleteRow = function (index) {
      for (var i = 0; i < scope.tableData.series.length; i++) {
          if (scope.tableData.series[i].data.length > 1) scope.tableData.series[i].data.splice(index, 1);
      }
      if (scope.tableData.categories.length > 1) scope.tableData.categories.splice(index, 1);
  };

  scope.addColumn = function () {
      var serLen = scope.tableData.series.length;
      var ser = angular.copy(scope.tableData.series[serLen - 1]);
      scope.tableData.series.push(ser);
  };

  scope.deleteColumn = function (index) {
      if (scope.tableData.series.length > 1) scope.tableData.series.splice(index, 1);
  };

}]);
