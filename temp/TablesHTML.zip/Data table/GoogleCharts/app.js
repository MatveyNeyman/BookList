var app = angular.module('app', []);

app.controller('MainCtrl', function($scope) {

  // $scope.data = [[{v: 1}, {v: 2}, {v: 3}],
  //                [{v: 4}, {v: 5}, {v: 6}]];
  
  // $scope.addRow = function() {
  //   var columnsNo = $scope.data[0].length;
  //   var rowCells = [];
  //   for (var i = 0; i < columnsNo; i++) {
  //     rowCells[i] = {v: ""};
  //   }
  //   $scope.data.push(rowCells);
  // }
  // $scope.deleteRow = function() {
  //   $scope.data.pop();
  // }
  // $scope.addColumn = function() {
  //   for (var i = 0; i < $scope.data.length; i++) {
  //     var cell = {v: ""};
  //     $scope.data[i].push(cell);
  //   }
  // }
  // $scope.deleteColumn = function() {
  //   for (var i = 0; i < $scope.data.length; i++) {
  //     $scope.data[i].pop();
  //   }
  // }

  // $scope.showme = function() {
  //   var s = "";
  //   for(var i = 0; i < $scope.data.length; i++) {
  //     for(var j = 0; j < $scope.data[i].length; j++)
  //       console.log("data [", i, ", ", j, "]: ", $scope.data[i][j].v);
  //   }
  // };

  $scope.resultData = {
                  "cols": [
                      { id: "", label: "", type: "string" }
                  ],
                  "rows": [
                      { "c": [
                          { "v": 0 }
                        ]
                      }
                  ]
              };

  $scope.addRow = function() {
    var rowLen = $scope.resultData.rows.length;
    var row = angular.copy($scope.resultData.rows[rowLen-1]);
    $scope.resultData.rows.push(row);
  }

  $scope.deleteRow = function() {
    if ($scope.resultData.rows.length > 1) $scope.resultData.rows.pop();
  }

  $scope.addColumn = function() {
    var colLen = $scope.resultData.cols.length;
    var colCell = angular.copy($scope.resultData.cols[colLen-1]);
    $scope.resultData.cols.push(colCell);
    for (var i = 0; i < $scope.resultData.rows.length; i++) {
        var rowLen = $scope.resultData.rows[i].c.length;
        var cell = angular.copy($scope.resultData.rows[i].c[rowLen-1]);
        $scope.resultData.rows[i].c.push(cell);
    }
  }

  $scope.deleteColumn = function() {
    for (var i = 0; i < $scope.resultData.rows.length; i++) {
      if ($scope.resultData.rows[i].c.length > 1) $scope.resultData.rows[i].c.pop();
    }
    if ($scope.resultData.cols.length > 1) $scope.resultData.cols.pop();
  }

  $scope.showme = function() {
    console.log($scope.resultData);
  };

});
